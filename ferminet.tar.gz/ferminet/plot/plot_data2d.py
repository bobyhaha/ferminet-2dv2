import numpy as np
import matplotlib.pyplot as plt

# Load checkpoint
ckpt = np.load("ferminet_hn_2025_06_27_10:55:12/qmcjax_ckpt_000812.npz", allow_pickle=True)
data = ckpt["data"].item()

# Get positions of electrons
#The shape is (batch_size, mcmc_sample_size, n_electrons * ndim)
positions = data["positions"]  # e.g. (1, 256, 4) for 2 electrons in 2D
print(positions.shape)
positions = positions[0]       # shape: (mcmc_sample_size, n_electrons * ndim)
# select the batch. 
# Reshape to (n_walkers, n_electrons, ndim)
positions = positions.reshape(positions.shape[0], -1, 3)  # (256, 2, 2)

# Flatten all electrons into one list of 2D positions
all_electron_positions = positions.reshape(-1, 3)  # shape (512, 2)

# Separate x and y for plotting
x = all_electron_positions[:, 0]
y = all_electron_positions[:, 1]

# Plot 2D electron density histogram
plt.figure(figsize=(6, 5))
plt.hist2d(x, y, bins=60, cmap="viridis", density=True)
plt.xlabel("x")
plt.ylabel("y")
plt.title("Electron density (2D)")
plt.colorbar(label="Density")
plt.axis("equal")
plt.tight_layout()
plt.show()
